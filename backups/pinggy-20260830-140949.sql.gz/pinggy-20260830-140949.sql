--
-- PostgreSQL database dump
--

\restrict UrG1FXHiXg9pSGa8oUOuHQcmKmtkKJ6UwDomKQBuD8bK4fojLLA8Gc5F3WVmwEw

-- Dumped from database version 14.19 (Homebrew)
-- Dumped by pg_dump version 14.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(200) NOT NULL,
    body text NOT NULL,
    level character varying(20) DEFAULT 'info'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    name character varying(120) NOT NULL,
    key_hash character varying(64) NOT NULL,
    prefix character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    key character varying(64) NOT NULL,
    value text,
    updated_by character varying(255),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_email character varying(255) NOT NULL,
    action character varying(50) NOT NULL,
    target character varying(255),
    details text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(32) NOT NULL,
    percent_off integer NOT NULL,
    max_redemptions integer DEFAULT 0 NOT NULL,
    redeemed integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT coupons_percent_off_check CHECK (((percent_off >= 1) AND (percent_off <= 100)))
);


ALTER TABLE public.coupons OWNER TO postgres;

--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    to_email character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    kind character varying(40) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_logs OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_no character varying(24) NOT NULL,
    user_email character varying(255) NOT NULL,
    payment_id uuid,
    plan character varying(20) NOT NULL,
    seats integer DEFAULT 1 NOT NULL,
    coupon_code character varying(32),
    amount numeric(10,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying NOT NULL,
    status character varying(20) DEFAULT 'paid'::character varying NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    method character varying(20) NOT NULL,
    plan character varying(20) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    provider_ref character varying(255),
    provider_payload text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    coupon_code character varying(32)
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id character varying(20) NOT NULL,
    name character varying(50) NOT NULL,
    price_inr numeric(10,2) DEFAULT 0 NOT NULL,
    price_usd numeric(10,2) DEFAULT 0 NOT NULL,
    tagline character varying(200),
    features text,
    cta_label character varying(50) DEFAULT 'Get Started'::character varying,
    popular boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: team_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    user_email character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.team_members OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(120) NOT NULL,
    owner_email character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    sender_email character varying(255) NOT NULL,
    is_staff boolean DEFAULT false NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ticket_messages OWNER TO postgres;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    subject character varying(200) NOT NULL,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tickets OWNER TO postgres;

--
-- Name: token_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_domains (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_id uuid NOT NULL,
    domain character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_domains OWNER TO postgres;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    name character varying(120),
    custom_domain character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    basic_auth_user character varying(120),
    basic_auth_pass character varying(120),
    ip_whitelist text,
    bearer_key character varying(64),
    https_only boolean DEFAULT false NOT NULL,
    fixed_subdomain character varying(50),
    tunnel_mode character varying(10) DEFAULT 'http'::character varying NOT NULL,
    tcp_port integer,
    team_id uuid
);


ALTER TABLE public.tokens OWNER TO postgres;

--
-- Name: tunnel_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tunnel_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_email character varying(255) NOT NULL,
    name character varying(120) NOT NULL,
    config text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tunnel_configs OWNER TO postgres;

--
-- Name: tunnels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tunnels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tunnel_id character varying(20) NOT NULL,
    subdomain character varying(50) NOT NULL,
    remote_port integer NOT NULL,
    local_port integer NOT NULL,
    protocol character varying(10) DEFAULT 'http'::character varying NOT NULL,
    user_email character varying(255),
    ssh_peer character varying(100),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    bytes_transferred bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    tunnel_expires_at timestamp with time zone,
    token character varying(64),
    bytes_sent bigint DEFAULT 0 NOT NULL,
    bytes_received bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.tunnels OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    full_name character varying(120),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    tunnel_token character varying(64) NOT NULL,
    custom_domain character varying(255),
    plan character varying(20) DEFAULT 'free'::character varying NOT NULL,
    plan_expires_at timestamp with time zone,
    seats integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    twofa_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
0025
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, body, level, active, created_at) FROM stdin;
85489f68-4d57-4348-8df9-645c5f0b7ee0	Welcome to Tunnel Pro!	New: custom domains are live for all Pro users.	success	t	2026-08-29 16:40:44.62771+00
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, user_email, name, key_hash, prefix, created_at, last_used_at, expires_at) FROM stdin;
4cd4779f-871d-4876-9625-1264da03d954	vtest@iraglobaltech.com	docs-test	0a0668a45b59c110a01fd7274207e0ca0212696add17b4298b5f818d4f1267bd	pk_uBHiv	2026-08-29 22:42:40.505755+00	\N	\N
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (key, value, updated_by, updated_at) FROM stdin;
stripe_secret_key	sk_test_51ExampleKey123	support@callingagents.in	2026-08-29 16:32:49.84501+00
stripe_enabled	true	support@callingagents.in	2026-08-29 16:32:49.84501+00
pro_price_inr	199	support@callingagents.in	2026-08-29 16:49:20.623625+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, actor_email, action, target, details, created_at) FROM stdin;
8c82a3dc-be58-4145-bc9c-b08306acbdee	vtest@iraglobaltech.com	user.register	vtest@iraglobaltech.com	self-service signup	2026-08-29 16:06:43.783822+00
abcaa817-c675-428b-ac21-ce024fc8b450	support@callingagents.in	user.update	vtest@iraglobaltech.com	full_name	2026-08-29 16:06:44.063723+00
cda07049-f1a3-4087-9ff6-70745b972dbc	support@callingagents.in	user.update	vtest@iraglobaltech.com	password	2026-08-29 16:07:03.491337+00
dbfcf084-9af2-4cb7-8ae8-e6239ace3edc	support@callingagents.in	user.update	vtest@iraglobaltech.com	is_active	2026-08-29 16:07:04.194693+00
1a31335c-9381-4632-b529-c758a9dd9324	support@callingagents.in	user.update	vtest@iraglobaltech.com	is_active	2026-08-29 16:07:04.915693+00
bf011f57-b40c-4fff-bc13-44911c0d90e7	support@callingagents.in	ip_monitor.config_update	\N	{"auto_block_enabled": false, "block_threshold": 777}	2026-08-29 16:07:05.207524+00
8dcdb638-9296-42cb-ae11-c55ca86bc700	support@callingagents.in	user.update	vtest@iraglobaltech.com	full_name	2026-08-29 16:10:24.48894+00
bbb0933d-6f91-4206-ae29-511a523729ab	support@callingagents.in	ip_monitor.config_update	\N	{"auto_block_enabled": false, "rate_window_seconds": 60, "block_threshold": 500, "block_duration_seconds": 3600}	2026-08-29 16:11:40.478752+00
fe7ac6c0-4c11-4297-a732-0b57c4def89c	support@callingagents.in	settings.update	\N	stripe_secret_key=***, stripe_enabled	2026-08-29 16:32:49.84501+00
6a2a5e13-422f-49bb-a670-f66a28826ebf	support@callingagents.in	coupon.create	LAUNCH20	20% off	2026-08-29 16:32:49.889126+00
a748c5aa-248b-4a0a-b5c2-84db7714215c	support@callingagents.in	announcement.create	Welcome to Tunnel Pro!	level=success	2026-08-29 16:40:44.62771+00
74271651-9dee-4917-b3e4-dcfdb5ed9b60	vtest@iraglobaltech.com	auth.forgot_password	vtest@iraglobaltech.com	reset link requested	2026-08-29 16:40:44.692488+00
670db566-a14d-43ac-85f1-d03237c56cbb	vtest@iraglobaltech.com	auth.reset_password	vtest@iraglobaltech.com	password reset via email token	2026-08-29 16:40:44.904596+00
c79411d4-190d-48b1-bf64-fb9ef868ab62	vtest@iraglobaltech.com	auth.reset_password	vtest@iraglobaltech.com	password reset via email token	2026-08-29 16:40:45.506711+00
059e6bb3-1732-43ec-a61e-682de95b0974	support@callingagents.in	plan.update	pro	price_inr = %s, features = %s, updated_at = now()	2026-08-29 16:49:19.18684+00
524b5103-173c-4be4-9146-534135184053	support@callingagents.in	settings.update	\N	pro_price_inr	2026-08-29 16:49:19.231404+00
4923be32-7c99-41be-867b-f011f1a7cc1a	support@callingagents.in	plan.update	pro	price_inr = %s, updated_at = now()	2026-08-29 16:49:20.60498+00
4bb9ef31-0670-4be5-b8be-99de32f86277	support@callingagents.in	settings.update	\N	pro_price_inr	2026-08-29 16:49:20.623625+00
1ef73087-a70e-4e20-86e1-9b883ad5ac59	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth	2026-08-29 17:25:50.023751+00
ec5a14ac-e822-45c7-aaf4-ebd39eda5891	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(1)	2026-08-29 17:25:50.091867+00
b082996c-fd71-429b-afce-6877be9d99d5	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(2)	2026-08-29 17:25:50.125993+00
332501df-c639-426f-a026-63dd8b7a99b9	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(0), bearer_key	2026-08-29 17:25:50.157115+00
fce22f94-fe10-4d83-8fdb-9e26fee553d1	support@callingagents.in	token.security	0b5fc14808896ec4	bearer_key=off, https_only=True	2026-08-29 17:25:50.200666+00
c95c236e-6bd1-4563-98ba-4b2ebcd0cc77	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth=off, https_only=False	2026-08-29 17:25:50.230566+00
16d2cb0f-3ac2-4c60-9808-44ac640dd122	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth	2026-08-29 17:27:33.544424+00
47631c50-8b4b-4328-8a7c-4d8f8e8f6030	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(1)	2026-08-29 17:27:33.821322+00
6e3e327e-ba97-40d2-a60d-1ccc567b23e0	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(2)	2026-08-29 17:27:33.973444+00
74e6c0e7-1935-4e36-9240-68a9e65bd1c7	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth=off, ip_whitelist(0), bearer_key	2026-08-29 17:27:34.110507+00
0df142e4-8b35-4be8-b051-3e39eeb332e8	support@callingagents.in	token.security	0b5fc14808896ec4	bearer_key=off, https_only=True	2026-08-29 17:27:34.480831+00
2a47235e-ddcd-4f69-af8d-82855a6a5eaf	support@callingagents.in	token.security	0b5fc14808896ec4	https_only=False	2026-08-29 17:27:34.677433+00
79ef6461-9b74-4271-a006-eba6519778c8	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth	2026-08-29 17:27:59.692428+00
f285844b-f611-4320-9e2d-c916d2e53649	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(1)	2026-08-29 17:27:59.785961+00
3a243a73-091b-420c-a38b-e16aa78f8935	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(2)	2026-08-29 17:27:59.828578+00
59af819b-99c9-49c0-97b5-656c8dfde143	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth=off, ip_whitelist(0), bearer_key	2026-08-29 17:27:59.870831+00
9330c221-da0f-4fff-84f1-88bc894e5aea	support@callingagents.in	token.security	0b5fc14808896ec4	bearer_key=off, https_only=True	2026-08-29 17:27:59.959613+00
73a60e41-3266-4f61-a024-660268a1bf9a	support@callingagents.in	token.security	0b5fc14808896ec4	https_only=False	2026-08-29 17:27:59.998396+00
a5c5be14-c957-4e82-a648-645fd431df95	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth	2026-08-29 17:28:57.66219+00
6ef00580-729e-4511-a5ca-42dae1e55dbd	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(1)	2026-08-29 17:28:57.765275+00
7a4bb2d7-97cc-4549-8945-591c56742fb6	support@callingagents.in	token.security	0b5fc14808896ec4	ip_whitelist(2)	2026-08-29 17:28:57.803773+00
930dfca1-3eff-46d6-b6bc-72a3ca9f3ef5	support@callingagents.in	token.security	0b5fc14808896ec4	basic_auth=off, ip_whitelist(0), bearer_key	2026-08-29 17:28:57.850412+00
22513f9b-e6eb-4fca-9e4b-db89535d58c7	support@callingagents.in	token.security	0b5fc14808896ec4	bearer_key=off, https_only=True	2026-08-29 17:28:57.958422+00
fcb2f047-996f-4627-8c15-18148c158bda	support@callingagents.in	token.security	0b5fc14808896ec4	https_only=False	2026-08-29 17:28:57.995821+00
2fdb6971-c86f-4edb-b790-d82a3ac80e72	support@callingagents.in	apikey.create	CI pipeline	prefix=pk_z-9-q	2026-08-29 17:38:34.588558+00
d0526a05-f209-4002-9bd2-881361264679	support@callingagents.in	apikey.revoke	CI pipeline	revoked	2026-08-29 17:38:34.908825+00
06188b91-a745-40ad-9a13-6d925005b149	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password login	2026-08-29 22:42:40.213046+00
a2be540b-c652-4825-875d-4927d34e289c	vtest@iraglobaltech.com	apikey.create	docs-test	prefix=pk_uBHiv	2026-08-29 22:42:40.505755+00
475af808-7765-4dba-a2b1-25a4e1eea725	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password login	2026-08-29 22:48:16.930143+00
e025890a-6c3a-4d9b-93d4-f9d863808b89	vtest@iraglobaltech.com	token.domain_add	shop.mytest.dev	token 3bfa5c15	2026-08-29 22:48:25.507333+00
fbd481ec-7024-47f6-a344-ce4a0a84c9fa	vtest@iraglobaltech.com	team.create	Platform Team	team created	2026-08-29 22:48:31.932362+00
b7b574c9-540c-4195-8945-3de07d818f6a	vtest@iraglobaltech.com	team.add_member	support@callingagents.in	role=admin	2026-08-29 22:48:31.960363+00
35d6606a-be81-4de1-9b89-103e6c407a03	vtest@iraglobaltech.com	ticket.create	TCP tunnel drops	ticket 3d3300d9-178c-4133-a3dd-23ab11907944	2026-08-29 22:48:42.479941+00
00797c87-6288-4760-a89e-dec72b400823	support@callingagents.in	auth.login	support@callingagents.in	password login	2026-08-29 22:48:42.511251+00
725e48a3-b604-4a56-9e4e-638cb74b6de2	support@callingagents.in	auth.login	support@callingagents.in	password login	2026-08-29 22:52:31.09587+00
e6967a8d-a119-4e2b-855d-c2cae3ece951	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password login	2026-08-29 22:53:03.36525+00
c45b03d3-0dd9-4464-a831-98a7ba41f348	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password login	2026-08-29 22:57:57.95925+00
1c25058e-313b-4ce5-9401-8940a89cf710	vtest@iraglobaltech.com	auth.2fa	vtest@iraglobaltech.com	2FA enabled	2026-08-29 22:57:58.202349+00
b6ef03f0-5a58-4c53-b4ed-8a1b7818529f	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-29 22:58:42.85096+00
f7b92dcc-91f5-45d1-aec5-a15d920e9803	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-29 22:58:43.1778+00
380ed4fa-f89f-4b22-9125-b3acd40e6650	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-29 22:59:31.61386+00
ee8c6b80-1dd9-4992-970d-3c9070f44d86	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-29 22:59:31.893322+00
94760759-7b5b-46a5-9c2c-43ec91da9146	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-29 22:59:32.191335+00
692b8e4f-3f9f-4198-a029-a4eece5b55f2	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-29 23:00:19.486941+00
77d872a9-d78c-4e7b-bc43-86f26ab924c1	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-29 23:00:11.485474+00
ca8f79d6-7e2b-4aff-9a2d-987fc8194a18	vtest@iraglobaltech.com	apikey.create	verify-key	prefix=pk_dbMkc	2026-08-30 00:54:53.428057+00
4b3a795f-3891-4a9e-9e14-835fcccba780	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 00:55:18.071408+00
173f230a-230e-4658-a05a-3a010e45d3b6	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 00:55:18.312843+00
49ff3297-8fee-483f-8a54-57b2cb953d31	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-30 00:55:18.582659+00
c523cb04-fb09-4d27-a1ab-89e08f2462f7	vtest@iraglobaltech.com	apikey.revoke	verify-key	revoked	2026-08-30 00:55:18.632863+00
3afef1ad-8570-41e6-85c6-9338484b5b07	support@callingagents.in	auth.login	support@callingagents.in	password login	2026-08-30 01:45:19.615059+00
911e9d36-dd20-4be9-bfbf-131d75b38d9e	support@callingagents.in	apikey.create	captest-1	prefix=pk_fT2JO	2026-08-30 01:45:19.885153+00
4c3389c2-b383-4438-b8c0-067c85385028	support@callingagents.in	apikey.create	captest-2	prefix=pk_LnEDL	2026-08-30 01:45:19.911618+00
b1d0e404-96af-41f6-97e6-aa3d4d574eec	support@callingagents.in	apikey.create	captest-3	prefix=pk_zBnQF	2026-08-30 01:45:19.935358+00
ed01e62f-526c-4195-9e39-698670dfa987	support@callingagents.in	apikey.create	captest-4	prefix=pk_fYlrl	2026-08-30 01:45:19.958277+00
16c7d3bf-2088-4055-875b-41584ffbe23b	support@callingagents.in	apikey.create	captest-5	prefix=pk_yuutC	2026-08-30 01:45:19.980049+00
8e18e07a-2f80-4421-9702-bbf81687395d	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 01:45:30.510906+00
5d11ae82-5f3a-4e96-b608-1411ad921993	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 01:45:30.73835+00
3828f609-3f73-4b6a-959f-0748dc7ee421	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-30 01:45:31.032954+00
31d455fa-ed78-4a88-9091-a3bd31101e4d	vtest@iraglobaltech.com	apikey.create	expiry-test	prefix=pk_7uUaN	2026-08-30 01:45:31.058086+00
8160fd71-ae05-4ddb-b45f-fb3c333ca269	vtest@iraglobaltech.com	apikey.create	ui-expiry-test	prefix=pk_1fYoD	2026-08-30 01:45:47.94107+00
e2e47dce-19ec-4781-badf-083bcc45117c	support@callingagents.in	auth.login	support@callingagents.in	password login	2026-08-30 01:57:30.185646+00
b0ecf54a-da9d-4652-8aa1-711dfa2052b7	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 01:57:30.428044+00
f450ba55-17f6-435a-b2fa-a974ce1635d7	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-30 01:57:30.740625+00
debab618-aa4c-4ccd-b2e2-28cc28d7e285	vtest@iraglobaltech.com	team.role_change	support@callingagents.in	-> member	2026-08-30 01:57:30.794528+00
95302b38-ef1a-45e0-a052-4ffb20532c4e	vtest@iraglobaltech.com	token.team_assign	3bfa5c15	team=1976d056-ede0-45b5-9cc3-1c509fe2835e	2026-08-30 01:57:30.814165+00
d48b03da-7cf4-41f4-866c-5a2f22a8caaa	vtest@iraglobaltech.com	team.role_change	support@callingagents.in	-> admin	2026-08-30 01:57:30.91266+00
257ee812-fe6e-41d1-94a6-3fe162e31eeb	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 01:57:56.969175+00
64ec4e0e-1b26-4aea-b8a1-1e17a5125823	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-30 01:57:57.258085+00
b8c07a61-215a-42d9-8b32-ff72330a797a	member@test.dev	user.register	member@test.dev	self-service signup	2026-08-30 01:57:57.309093+00
9634dcbb-a53f-4c0b-abe7-656fec3fdf46	member@test.dev	auth.login	member@test.dev	password login	2026-08-30 01:57:57.546431+00
dde6850f-2d25-4f5a-a57c-229b07a73e26	vtest@iraglobaltech.com	team.add_member	member@test.dev	role=member	2026-08-30 01:57:57.795662+00
361475cd-199d-401c-9968-e7aea14a6e15	vtest@iraglobaltech.com	token.team_assign	c508437e	team=1976d056-ede0-45b5-9cc3-1c509fe2835e	2026-08-30 01:57:57.814456+00
5e41061e-5009-449d-a19f-5b774fc7560f	vtest@iraglobaltech.com	team.role_change	member@test.dev	-> admin	2026-08-30 01:58:18.395558+00
97a107d9-99a8-45bc-9996-28bc7241eaec	member@test.dev	token.team_assign	c508437e	team=None	2026-08-30 01:58:18.430122+00
b97a2fa2-d6a2-4899-99e8-759a8e40a377	vtest@iraglobaltech.com	team.role_change	member@test.dev	-> member	2026-08-30 01:58:18.479035+00
1e342e94-9e75-44f9-8b7d-b1487625d6a7	vtest@iraglobaltech.com	token.team_assign	c508437e	team=1976d056-ede0-45b5-9cc3-1c509fe2835e	2026-08-30 01:58:18.495718+00
a2fce704-66d8-449b-805b-5fc873b56e02	vtest@iraglobaltech.com	auth.otp_challenge	vtest@iraglobaltech.com	2FA code sent	2026-08-30 02:48:56.301688+00
58b64458-b4ce-4240-92f1-dda0292ea6d8	vtest@iraglobaltech.com	auth.login	vtest@iraglobaltech.com	password + OTP login	2026-08-30 02:48:56.601772+00
5379c4d6-2624-491d-b089-c86b084547f4	vtest@iraglobaltech.com	user.custom_domain	callingagents.in	token=c508437e-f798-422f-9da2-242792d15f7e	2026-08-30 02:48:56.631014+00
35a11b3f-4aad-42f3-9163-9803037bee5a	vtest@iraglobaltech.com	token.domain_add	blog.mytest.dev	token c508437e	2026-08-30 03:08:56.695317+00
5ac581c7-b182-49b3-aa5b-6160fc9c822d	vtest@iraglobaltech.com	token.domain_add	demohub.mytest.dev	token c508437e	2026-08-30 03:08:56.768301+00
7a61cdc2-541a-488c-a787-7fbb4332d677	vtest@iraglobaltech.com	user.custom_domain	demohub.mytest.dev	token=c508437e-f798-422f-9da2-242792d15f7e	2026-08-30 03:08:56.783575+00
28298b2a-10c1-429d-bf7d-ba374b3efae3	vtest@iraglobaltech.com	token.domain_remove	blog.mytest.dev	token c508437e	2026-08-30 03:08:56.878129+00
41989710-ba2d-44e3-be69-25376e45e2bb	vtest@iraglobaltech.com	user.custom_domain	callingagents.in	token=c508437e-f798-422f-9da2-242792d15f7e	2026-08-30 03:08:56.894809+00
33ca9aa8-476a-429c-ab60-955b502cf8d6	vtest@iraglobaltech.com	token.domain_add	ui-test.mytest.dev	token c508437e	2026-08-30 03:10:08.695218+00
26f37e07-8cc8-4dc9-9e55-4a2a76a0185f	vtest@iraglobaltech.com	token.domain_remove	ui-test.mytest.dev	token c508437e	2026-08-30 03:10:09.714052+00
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coupons (id, code, percent_off, max_redemptions, redeemed, active, expires_at, created_at) FROM stdin;
c0d322ce-8c4b-497a-a30c-b0bbaca0e76e	LAUNCH20	20	100	1	t	\N	2026-08-29 16:32:49.889126+00
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_logs (id, to_email, subject, kind, status, error, created_at) FROM stdin;
068e87f1-f073-4928-83e8-ffbe2f674748	vtest@iraglobaltech.com	Reset your Tunnel password	reset	failed	SMTP not configured	2026-08-29 16:40:44.692488+00
b9742c2a-e3a7-45b6-9280-cc391e614869	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:19:43.701652+00
49fbe355-413c-4bcf-9f63-94ba5955f66a	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:27:33.014852+00
3f226ae4-8aa9-4e19-ac7a-f2347c0c9fb7	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:28:00.028863+00
e3001d51-fbe4-4929-949e-1baa6026170c	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:28:58.030314+00
6e96f40d-532d-46f6-a5d4-75c0514e71d3	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:34:54.111695+00
be208374-eb2b-42dc-b963-494576761576	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:34:56.315169+00
983e4235-802b-4351-9a20-e96f2751af63	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:35:48.442963+00
aa8ef13a-4da5-41db-8627-55e6422c0713	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:41:38.008246+00
a68c38d9-ee75-4cc6-8c47-c5f612ec8908	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:50:29.666781+00
802680d2-37a8-4504-a10e-d1d9494756a5	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:52:50.687183+00
e397dad0-9709-4b6d-8be9-0ba1c259e2f1	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 17:53:22.289537+00
70779923-64df-4b1e-b48e-f27451e82345	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 22:31:04.919203+00
e0d23674-92d1-4483-aa80-7cd6c7b609ed	support@callingagents.in	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 22:32:02.719192+00
8c8b41a7-e87e-4513-bcc2-18f750ff833a	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 22:33:47.883078+00
852e196f-5d97-4d57-b5ae-35d12a2a2912	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:42:40.213046+00
29099153-6412-4430-a377-424f569d4212	vtest@iraglobaltech.com	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-29 22:42:40.505755+00
5219626d-f882-4041-9adb-f551b125ae9a	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:48:16.930143+00
aa704c6c-df0a-434b-95ab-f77d33cbed2a	support@callingagents.in	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:48:42.511251+00
cb69ffa8-8a28-4209-b701-fc669de542d0	vtest@iraglobaltech.com	Re: your IRAGT support ticket — 3d3300d9	ticket	failed	SMTP not configured	2026-08-29 22:48:42.75478+00
b7cbd68b-c0d7-4eef-b17e-d21f65692e32	support@callingagents.in	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:52:31.09587+00
8b734ec5-62d0-4caa-99df-433dc3fafb29	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-29 22:52:53.665136+00
fe480dde-ee3b-4740-a553-043ec14e13d4	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:53:03.36525+00
142b3534-2dfa-467f-8218-2a6a048a267f	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:57:57.95925+00
40aa55ef-2868-4c56-b7a4-69eb580199c0	vtest@iraglobaltech.com	IRAGT verification code: 736059	otp	failed	SMTP not configured	2026-08-29 22:58:42.85096+00
31d3e099-6878-48fe-acc1-3787ed0176db	vtest@iraglobaltech.com	IRAGT verification code: 960760	otp	failed	SMTP not configured	2026-08-29 22:58:43.1778+00
9fe0b73b-532a-457b-a926-d9475364a993	vtest@iraglobaltech.com	IRAGT verification code: 723894	otp	failed	SMTP not configured	2026-08-29 22:59:31.61386+00
43898cce-4a73-4048-b0b8-98c850c19692	vtest@iraglobaltech.com	IRAGT verification code: 153709	otp	failed	SMTP not configured	2026-08-29 22:59:31.893322+00
f711934a-7ea3-4375-86b6-8c69bc1a73dd	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 22:59:32.191335+00
69fe3105-30b7-416c-a44b-8451f476b457	vtest@iraglobaltech.com	IRAGT verification code: 357575	otp	failed	SMTP not configured	2026-08-29 23:00:11.485474+00
57df0dbe-73d6-4feb-acbc-4d496794f1a6	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-29 23:00:19.486941+00
d7e955f1-502c-412f-94e3-dde9ac231d77	vtest@iraglobaltech.com	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 00:54:53.428057+00
5be1686e-cbd1-4de5-9f72-8a5993a83267	vtest@iraglobaltech.com	IRAGT verification code: 997119	otp	failed	SMTP not configured	2026-08-30 00:55:18.071408+00
05c945af-1493-43ec-8c7f-7f192c7a79ee	vtest@iraglobaltech.com	IRAGT verification code: 636589	otp	failed	SMTP not configured	2026-08-30 00:55:18.312843+00
2c24e344-daa9-4686-a9fb-ba7efe44af67	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 00:55:18.582659+00
6a3cb7c2-8583-4c9c-aeec-88cbedf75756	support@callingagents.in	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:45:19.615059+00
90a45018-f4ae-45db-ae7a-8eb982128c38	support@callingagents.in	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:19.885153+00
ea7f8395-2348-4318-8378-0cc6e9f90c2f	support@callingagents.in	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:19.911618+00
27980882-7c6a-4cab-9d49-07065ca70575	support@callingagents.in	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:19.935358+00
74934e4b-e569-4105-b6d6-bcead22bfa2e	support@callingagents.in	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:19.958277+00
3b10a439-0dbd-4274-9362-72361c3df044	support@callingagents.in	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:19.980049+00
873c37dd-4098-4041-abdc-e4a8577dee04	vtest@iraglobaltech.com	IRAGT verification code: 065869	otp	failed	SMTP not configured	2026-08-30 01:45:30.510906+00
5d5669c6-d51e-4080-baae-4b34b334a512	vtest@iraglobaltech.com	IRAGT verification code: 833764	otp	failed	SMTP not configured	2026-08-30 01:45:30.73835+00
d2bc7c8e-f9e6-4ced-8c84-c296cf8d0020	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:45:31.032954+00
44efe83d-9997-49b1-9836-55bf237cf430	vtest@iraglobaltech.com	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:31.058086+00
aba2405a-5a70-4ee0-a60a-5dbd32a44018	vtest@iraglobaltech.com	Your IRAGT API key was created	apikey	failed	SMTP not configured	2026-08-30 01:45:47.94107+00
ee91504e-522e-4747-8962-5fd2f988cc3a	support@callingagents.in	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:57:30.185646+00
310378f4-7ecb-41f4-8441-e7201b461f3f	vtest@iraglobaltech.com	IRAGT verification code: 180267	otp	failed	SMTP not configured	2026-08-30 01:57:30.428044+00
170c6031-f803-45c0-9f33-81d7405c3b9a	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:57:30.740625+00
741bf053-2155-42f4-b26a-ee00d003eb76	vtest@iraglobaltech.com	IRAGT verification code: 832307	otp	failed	SMTP not configured	2026-08-30 01:57:56.969175+00
9c992461-0a66-4bfa-bda4-7c73b1520746	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:57:57.258085+00
77f2c2d4-e5e9-42b4-8351-c41afd7100a9	member@test.dev	Welcome to IRAGT ⚡	welcome	failed	SMTP not configured	2026-08-30 01:57:57.309093+00
b8f1297f-2a74-4a38-868f-75640f25cb2c	member@test.dev	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 01:57:57.546431+00
9f81f7d3-4ca7-41a0-bafb-2a9b93800f62	vtest@iraglobaltech.com	IRAGT verification code: 801911	otp	failed	SMTP not configured	2026-08-30 02:48:56.301688+00
a8e9008d-6494-4b43-917d-ded6791477ce	vtest@iraglobaltech.com	New login to your IRAGT account	login	failed	SMTP not configured	2026-08-30 02:48:56.601772+00
8059fb59-4f45-4727-bbcb-e685355e74f6	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-30 02:49:48.526795+00
1b6deb32-9cc6-4324-bbcc-b46db4f2ce90	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-30 03:55:33.647931+00
87d284a3-145b-4b25-8c7a-9f7529aff8f7	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-30 03:56:46.480897+00
d9c25192-dbc2-457f-a946-a2e1cd1d1b2f	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-30 03:57:13.700556+00
cfb57db5-a177-4e2d-8c4a-e22198afefac	vtest@iraglobaltech.com	Your tunnel was stopped	tunnel_stopped	failed	SMTP not configured	2026-08-30 08:37:09.593926+00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, invoice_no, user_email, payment_id, plan, seats, coupon_code, amount, currency, status, issued_at) FROM stdin;
38192812-0b8d-44ff-8ed2-528dd978daa9	INV-202608-7BE0598B	vtest@iraglobaltech.com	7be0598b-2c6d-4d77-a995-8f32ffadb62d	pro	1	LAUNCH20	159.20	INR	paid	2026-08-29 16:49:39.622966+00
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (id, user_email, token_hash, expires_at, used_at, created_at) FROM stdin;
6d1eee3c-dd48-41b7-bed8-4b7acc51e323	vtest@iraglobaltech.com	ba597dc08ca97e05d2aac90a9d3c3c01635f855aa834d6be4ba4d50c6152b57d	2026-08-29 17:10:44.693016+00	\N	2026-08-29 16:40:44.692488+00
9a327d99-806b-4fe9-a112-433d8f08fe4f	vtest@iraglobaltech.com	1098661ab59ceee3f7289b29d8d9a6ba4a8465f593b2407142475d007dc6004c	2026-08-29 17:10:44.872996+00	2026-08-29 16:40:44.904596+00	2026-08-29 16:40:44.873399+00
6b123d1a-8624-4794-b7d8-013632c0b0c4	vtest@iraglobaltech.com	9dea5e224e52ae9b5523819fd3e704dc30b65f462ac36a545094da25a5900d3f	2026-08-29 17:10:45.477706+00	2026-08-29 16:40:45.506711+00	2026-08-29 16:40:45.478253+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, user_email, method, plan, amount, currency, status, provider_ref, provider_payload, created_at, updated_at, coupon_code) FROM stdin;
7be0598b-2c6d-4d77-a995-8f32ffadb62d	vtest@iraglobaltech.com	stripe	pro	159.20	INR	paid	cs_test_e2e_001	{"id": "cs_test_e2e_001"}	2026-08-29 16:49:19.515459+00	2026-08-29 16:49:39.622966+00	LAUNCH20
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, name, price_inr, price_usd, tagline, features, cta_label, popular, active, sort_order, updated_at) FROM stdin;
free	Free	0.00	0.00	Free for life	Single command tunneling\nHTTP(S) tunnels\n60 minutes tunnel timeout\nRandom subdomains\nUnlimited data transfer	Get Started Free	f	t	1	2026-08-29 16:48:49.421092+00
enterprise	Enterprise	0.00	0.00	For teams that need dedicated infrastructure	Everything in Pro plan\nUnlimited persistent tunnels\nUnlimited custom domains\nDedicated servers\nAPI to manage tunnels\nPriority call support	Contact Sales	f	t	3	2026-08-29 16:48:49.421092+00
pro	Pro	199.00	2.99	For developers who need more	Everything in Free plan\nPersistent tunnels (no timeout)\nFixed subdomain per token\n1 Custom domain\nMultiple tunnels\nPriority support\nNEW: 30-day money-back guarantee	Upgrade to Pro	t	t	2	2026-08-29 16:49:20.60498+00
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_members (id, team_id, user_email, role, added_at) FROM stdin;
5d0a6209-4353-4c02-a344-e8c6c8eb8432	1976d056-ede0-45b5-9cc3-1c509fe2835e	vtest@iraglobaltech.com	admin	2026-08-29 22:48:31.932362+00
6259590b-8f16-4c93-90e7-39bddff379fd	1976d056-ede0-45b5-9cc3-1c509fe2835e	support@callingagents.in	admin	2026-08-29 22:48:31.960363+00
b69609c0-0622-4aaf-8429-14b6790f6606	1976d056-ede0-45b5-9cc3-1c509fe2835e	member@test.dev	member	2026-08-30 01:57:57.795662+00
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, name, owner_email, created_at) FROM stdin;
1976d056-ede0-45b5-9cc3-1c509fe2835e	Platform Team	vtest@iraglobaltech.com	2026-08-29 22:48:31.932362+00
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_messages (id, ticket_id, sender_email, is_staff, body, created_at) FROM stdin;
17382ab2-ba4d-4424-bb52-98f8bca050cd	3d3300d9-178c-4133-a3dd-23ab11907944	vtest@iraglobaltech.com	f	My TCP tunnel disconnects after 5 min.	2026-08-29 22:48:42.479941+00
6b02cee6-c7cb-46b5-a3f1-47130fa4057a	3d3300d9-178c-4133-a3dd-23ab11907944	support@callingagents.in	t	We are looking into it — please share your tunnel subdomain.	2026-08-29 22:48:42.75478+00
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tickets (id, user_email, subject, status, created_at, updated_at) FROM stdin;
3d3300d9-178c-4133-a3dd-23ab11907944	vtest@iraglobaltech.com	TCP tunnel drops	closed	2026-08-29 22:48:42.479941+00	2026-08-29 22:48:42.807195+00
\.


--
-- Data for Name: token_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_domains (id, token_id, domain, created_at) FROM stdin;
dd007a70-fc21-4da3-bca4-8ce24b81872a	3bfa5c15-6414-40fa-85be-ca432ad06ea5	shop.mytest.dev	2026-08-29 22:48:25.507333+00
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tokens (id, user_email, token, name, custom_domain, created_at, updated_at, basic_auth_user, basic_auth_pass, ip_whitelist, bearer_key, https_only, fixed_subdomain, tunnel_mode, tcp_port, team_id) FROM stdin;
c508437e-f798-422f-9da2-242792d15f7e	vtest@iraglobaltech.com	af1d6b19be037035	New Token	callingagents.in	2026-08-30 01:57:57.283221+00	2026-08-30 03:10:19.055094+00	\N	\N	\N	\N	f	0f4f398	http	\N	1976d056-ede0-45b5-9cc3-1c509fe2835e
4afe47ff-6b3b-4e9c-be66-d3ba74ce7534	support@callingagents.in	0b5fc14808896ec4	Default	\N	2026-08-29 15:41:53.657051+00	2026-08-29 17:35:43.379116+00	\N	\N	\N	\N	f	myapi	http	\N	\N
983658f1-b43b-4a10-9fdc-4241530e2a01	support@callingagents.in	9dad5748e08820df	sdk-made	\N	2026-08-29 17:38:34.70979+00	2026-08-29 17:38:34.70979+00	\N	\N	\N	\N	f	sdktest	http	\N	\N
\.


--
-- Data for Name: tunnel_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tunnel_configs (id, user_email, name, config, created_at) FROM stdin;
27e89847-a3cb-4196-aff0-041dfbd60c51	vtest@iraglobaltech.com	Django dev	{"preset": "Django (runserver) \\u2014 :8000", "local_addr": "127.0.0.1:8000", "platform": "mac", "keep_alive": true, "auto_reconnect": true}	2026-08-29 17:19:40.378732+00
\.


--
-- Data for Name: tunnels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tunnels (id, tunnel_id, subdomain, remote_port, local_port, protocol, user_email, ssh_peer, status, request_count, bytes_transferred, created_at, closed_at, tunnel_expires_at, token, bytes_sent, bytes_received) FROM stdin;
06283ea3-5fc7-4405-aa2f-3d38af2cb53c	e3az2pguva1k	0f4f398	53474	0	http	vtest@iraglobaltech.com	127.0.0.1:53472	disconnected	1	64	2026-08-30 08:36:48.737019+00	2026-08-30 08:37:09.593926+00	\N	af1d6b19be037035	0	0
e2ef689f-808c-489a-8f52-c0189b14fa6a	21scdca1hl99	kw8ll8g	65265	0	http	support@callingagents.in	127.0.0.1:65263	disconnected	0	0	2026-08-29 15:35:36.33071+00	2026-08-29 15:35:47.858072+00	\N	0b5fc14808896ec4	0	0
91d87d8e-838d-4ec6-8cc8-fc07483c8919	fbhi3pibgx6d	jwrvvf1	65457	0	http	support@callingagents.in	127.0.0.1:65455	disconnected	0	0	2026-08-29 15:36:19.369142+00	2026-08-29 15:36:20.907174+00	\N	0b5fc14808896ec4	0	0
53b45156-233c-4f23-adc8-084821bc4e44	w1uw7znbg4n0	a73139j	49787	0	http	support@callingagents.in	127.0.0.1:49785	disconnected	0	0	2026-08-29 15:42:05.141741+00	2026-08-29 15:42:06.676317+00	\N	0b5fc14808896ec4	0	0
727962ec-5e5a-47cf-92aa-587aaa0da597	25zthbr8uk9h	2w8liwp	53786	0	http	vtest@iraglobaltech.com	127.0.0.1:53784	disconnected	0	0	2026-08-29 16:09:17.704367+00	2026-08-29 16:09:19.243682+00	\N	5b9ae2cb44202d86	0	0
cd4fe68c-613c-4345-8a11-cbdbf31f53d5	ir40emgvs8y4	w6gg8u1	56689	0	http	support@callingagents.in	127.0.0.1:56687	disconnected	0	0	2026-08-29 16:22:08.28538+00	2026-08-29 16:22:09.862377+00	\N	0b5fc14808896ec4	0	0
28f34d3c-654e-4927-a2e4-4ae4fa898b69	ldqou71ulrgf	jnb65k8	56961	0	http	support@callingagents.in	127.0.0.1:56959	disconnected	3	4188	2026-08-29 16:23:18.43013+00	2026-08-29 16:23:21.025638+00	\N	0b5fc14808896ec4	0	0
3efc2b0c-c040-4f88-b090-128e072bf254	jnsc0mvk8vvj	myapi	62150	0	http	support@callingagents.in	127.0.0.1:62148	disconnected	1	5011	2026-08-29 22:31:56.019516+00	2026-08-29 22:32:02.719192+00	\N	0b5fc14808896ec4	11	5000
dab3c4d5-63b5-43f4-a68f-2250b282fd5d	mm7ng9lyk3tt	2hc5pge	51551	0	http	support@callingagents.in	127.0.0.1:51547	disconnected	1	1396	2026-08-29 17:19:42.153198+00	2026-08-29 17:19:43.701652+00	\N	0b5fc14808896ec4	0	0
f5603d3f-b0d9-470b-8dac-3dcd24fe80aa	mzhmbe05cw7k	6mjix82	52588	0	http	support@callingagents.in	127.0.0.1:52586	disconnected	0	0	2026-08-29 17:26:45.972105+00	2026-08-29 17:27:33.014852+00	\N	0b5fc14808896ec4	0	0
df8d0969-f1d8-4eab-a469-d27c945a374c	zli8h697y596	s6cjr6z	52920	0	http	support@callingagents.in	127.0.0.1:52918	disconnected	11	8376	2026-08-29 17:28:53.035703+00	2026-08-29 17:28:58.030314+00	\N	0b5fc14808896ec4	0	0
faa8e04c-eddc-4428-886e-909a17c0ea62	fz509ca5hbi8	ttvp861	52722	0	http	support@callingagents.in	127.0.0.1:52720	disconnected	11	15356	2026-08-29 17:27:55.159562+00	2026-08-29 17:28:00.028863+00	\N	0b5fc14808896ec4	0	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, full_name, created_at, updated_at, role, tunnel_token, custom_domain, plan, plan_expires_at, seats, is_active, twofa_enabled) FROM stdin;
c566c434-cbe6-4899-9d90-7978493d9094	support@callingagents.in	$2b$12$pBhef6QZYIfaWcFps6/dweSOwSIc9gKYYILyW7I9oaMIEcVMNNni6	Default Admin	2026-08-29 14:50:14.945861+00	2026-08-29 15:32:10.336398+00	admin	0b5fc14808896ec4	\N	free	\N	1	t	f
2ba91bd5-2c66-4932-9fc3-c8fea79e337b	member@test.dev	$2b$12$5dYyjHK6acX9C9JAQ.lZT.1t0yEiwEN13obkI2jXbIKN.6jT1yNsi	Team Member	2026-08-30 01:57:57.309093+00	2026-08-30 01:57:57.309093+00	user	8ba009855d802ae5	\N	free	\N	1	t	f
84939e77-3037-4f8e-9fa2-909b5e922e8e	vtest@iraglobaltech.com	$2b$12$3Oj.rp4gSay4xkROPrqXteyQ.GONqEoyy1FGArHzaJo80A8N3jl3q	V Test Renamed UI	2026-08-29 16:06:43.783822+00	2026-08-30 03:08:56.894809+00	user	5b9ae2cb44202d86	callingagents.in	pro	2026-09-29 16:49:39.622966+00	1	t	t
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_key UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_no_key UNIQUE (invoice_no);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_token_hash_key UNIQUE (token_hash);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_team_id_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_user_email_key UNIQUE (team_id, user_email);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: token_domains token_domains_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_domains
    ADD CONSTRAINT token_domains_domain_key UNIQUE (domain);


--
-- Name: token_domains token_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_domains
    ADD CONSTRAINT token_domains_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_custom_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_custom_domain_key UNIQUE (custom_domain);


--
-- Name: tokens tokens_fixed_subdomain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_fixed_subdomain_key UNIQUE (fixed_subdomain);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_tcp_port_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_tcp_port_key UNIQUE (tcp_port);


--
-- Name: tokens tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_token_key UNIQUE (token);


--
-- Name: tunnel_configs tunnel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tunnel_configs
    ADD CONSTRAINT tunnel_configs_pkey PRIMARY KEY (id);


--
-- Name: tunnels tunnels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tunnels
    ADD CONSTRAINT tunnels_pkey PRIMARY KEY (id);


--
-- Name: tunnels tunnels_subdomain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tunnels
    ADD CONSTRAINT tunnels_subdomain_key UNIQUE (subdomain);


--
-- Name: tunnels tunnels_tunnel_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tunnels
    ADD CONSTRAINT tunnels_tunnel_id_key UNIQUE (tunnel_id);


--
-- Name: invoices uq_invoices_payment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT uq_invoices_payment UNIQUE (payment_id);


--
-- Name: users users_custom_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_custom_domain_key UNIQUE (custom_domain);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tunnel_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tunnel_token_key UNIQUE (tunnel_token);


--
-- Name: idx_announcements_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_announcements_active ON public.announcements USING btree (active, created_at DESC);


--
-- Name: idx_api_keys_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_keys_expires ON public.api_keys USING btree (expires_at);


--
-- Name: idx_apikeys_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_apikeys_user ON public.api_keys USING btree (user_email);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_actor ON public.audit_logs USING btree (actor_email);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_coupons_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_coupons_code ON public.coupons USING btree (code);


--
-- Name: idx_email_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_logs_created ON public.email_logs USING btree (created_at DESC);


--
-- Name: idx_email_logs_kind; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_logs_kind ON public.email_logs USING btree (kind);


--
-- Name: idx_invoices_issued; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_issued ON public.invoices USING btree (issued_at DESC);


--
-- Name: idx_invoices_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_user ON public.invoices USING btree (user_email);


--
-- Name: idx_payments_ref; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_ref ON public.payments USING btree (provider_ref);


--
-- Name: idx_payments_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_user ON public.payments USING btree (user_email);


--
-- Name: idx_pwresets_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pwresets_email ON public.password_resets USING btree (user_email);


--
-- Name: idx_tconfigs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tconfigs_user ON public.tunnel_configs USING btree (user_email);


--
-- Name: idx_teammembers_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teammembers_team ON public.team_members USING btree (team_id);


--
-- Name: idx_teammembers_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teammembers_user ON public.team_members USING btree (user_email);


--
-- Name: idx_ticketmsgs_ticket; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticketmsgs_ticket ON public.ticket_messages USING btree (ticket_id);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_status ON public.tickets USING btree (status, updated_at DESC);


--
-- Name: idx_tickets_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_user ON public.tickets USING btree (user_email);


--
-- Name: idx_tokendomains_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokendomains_token ON public.token_domains USING btree (token_id);


--
-- Name: idx_tokens_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokens_token ON public.tokens USING btree (token);


--
-- Name: idx_tokens_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tokens_user_email ON public.tokens USING btree (user_email);


--
-- Name: idx_tunnels_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tunnels_status ON public.tunnels USING btree (status);


--
-- Name: idx_tunnels_subdomain; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tunnels_subdomain ON public.tunnels USING btree (subdomain);


--
-- Name: idx_tunnels_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tunnels_token ON public.tunnels USING btree (token);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_tunnel_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_tunnel_token ON public.users USING btree (tunnel_token);


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: tokens tokens_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: tokens tokens_user_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_user_email_fkey FOREIGN KEY (user_email) REFERENCES public.users(email) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict UrG1FXHiXg9pSGa8oUOuHQcmKmtkKJ6UwDomKQBuD8bK4fojLLA8Gc5F3WVmwEw

